var app = new Vue({
    el: '#app',
    data: {
        url: "https://api.jsonbin.io/b/5beed6953c134f38b019ffba",
        teams: [],
        results: [],
        matches: [],
        match: {},
        page: 'indexPage',

    },
    methods: {
        fetchData() {
            fetch(this.url, {
                    method: 'GET',
                })
                .then(function (data) {
                    return data.json();
                })

                .then(function (myData) {
                    app.teams = myData.teams;
                    app.results = myData.teams[4].results;
                    app.matches = myData.teams[4].matches;
                })
        },

        showPage(pageName) { //function to change id
            this.page = pageName;
        },

        getMatchInfo(object) {
            this.match = object;
        },

        hideNavBar() {
            if (clicked) {
                collapse("hide");
            }
        },

        login() {

            // https://firebase.google.com/docs/auth/web/google-signin

            // Provider
            var provider = new firebase.auth.GoogleAuthProvider();

            // How to Log In
            firebase.auth().signInWithPopup(provider);

            console.log("login");

        },

        logout() {
            firebase.auth().signOut().then(function () {
                console.log("logged out");
                // Sign-out successful.
            }, function (error) {
                console.log("not logged out");
                // An error happened.
            });
        },

        writeNewPost() {

            // https://firebase.google.com/docs/database/web/read-and-write

            // Values
            var textInput = document.getElementById("textInput").value;
            console.log(textInput);

            var userName = firebase.auth().currentUser.email;
            console.log(userName);

            // A post entry.

            var message = {
                messageText: textInput,
                name: userName,
            }

            console.log(message);

            // Get a key for a new Post.

            firebase.database().ref('myChat').push(message);

            //Write data

            console.log("write");

        },
        getPosts() {

            firebase.database().ref('myChat').on('value', function (data) {
                var posts = document.getElementById("posts");
                posts.innerHTML = "";

                var messages = data.val();

                for (var key in messages) {
                    var text = document.createElement("div");
                    var element = messages[key];

                    text.append(element.messageText);
                    posts.append(text);
                }
            })
            console.log("getting posts");
        }
    },
    created() {
        this.getPosts();
        this.fetchData();

    }
})







//document.getElementById("login").addEventListener("click", login);
//document.getElementById("create-post").addEventListener("click", writeNewPost);
//
//
//getPosts();
//
//function login() {
//
//    // https://firebase.google.com/docs/auth/web/google-signin
//
//    // Provider
//    var provider = new firebase.auth.GoogleAuthProvider();
//
//    // How to Log In
//    firebase.auth().signInWithPopup(provider);
//
//    console.log("login");
//
//}
//
//
//function writeNewPost() {
//
//    // https://firebase.google.com/docs/database/web/read-and-write
//
//    // Values
//    var textInput = document.getElementById("textInput").value;
//    console.log(textInput);
//
//    var userName = firebase.auth().currentUser.email;
//    console.log(userName);
//
//    // A post entry.
//
//    var message = {
//        messageText: textInput,
//        name: userName,
//    }
//
//    console.log(message);
//
//    // Get a key for a new Post.
//
//    firebase.database().ref('myChat').push(message);
//
//    //Write data
//
//    console.log("write");
//
//}
//
//
//function getPosts() {
//
//    firebase.database().ref('myChat').on('value', function (data) {
//        var posts = document.getElementById("posts");
//        posts.innerHTML = "";
//
//        var messages = data.val();
//
//        for (var key in messages) {
//            var text = document.createElement("div");
//            var element = messages[key];
//
//            text.append(element.messageText);
//            posts.append(text);
//        }
//
//    })
//
//    console.log("getting posts");
//
//}









// hide text first
document.getElementById("more1").style.display = "none";
document.getElementById("more2").style.display = "none";

// then function to 
function showReadMoreReadLess(id_dots, id_moreText, id_btnText) { // passing id names as params. 

    // apply function to selected IDs
    var dots = document.getElementById(id_dots);
    var moreText = document.getElementById(id_moreText);
    var btnText = document.getElementById(id_btnText);

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.innerHTML = "Read less";
        moreText.style.display = "inline";
    }
}

// no need to call function. Because called in HTML

function openForm() {
    document.getElementById("myForm").style.display = "block";
}

function closeForm() {
    document.getElementById("myForm").style.display = "none";
}
